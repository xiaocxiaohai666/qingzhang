@echo off
rem ============================================================
rem  QingZhang launcher
rem  Opens the ledger in a clean app window (no address bar),
rem  so it feels like a desktop program instead of a web page.
rem
rem  This file is deliberately written in pure ASCII: Chinese
rem  text inside a .bat is a common source of mojibake, and the
rem  script does not need to contain any Chinese at all - it
rem  locates the .html next to itself by wildcard.
rem ============================================================
setlocal enabledelayedexpansion

rem --- locate the html sitting next to this script ---
set "TARGET="
for %%F in ("%~dp0*.html") do if not defined TARGET set "TARGET=%%~fF"
if not defined TARGET (
  echo [ERROR] No .html file found in this folder.
  echo         Keep this .bat next to QingZhang html file.
  pause
  exit /b 1
)

rem --- build a file:// URL (backslashes and spaces must be encoded) ---
set "URL=file:///!TARGET:\=/!"
set "URL=!URL: =%%20!"

rem --- locate Edge ---
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "!EDGE!" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "!EDGE!" set "EDGE="

if defined EDGE (
  start "" "!EDGE!" --app="!URL!"
) else (
  echo Edge not found. Opening with the default browser instead...
  start "" "!URL!"
)
exit /b 0
